player_db = {
    "J. Jefferson": {
        "full": "Justin Jefferson",
        "team": "MIN",
        "pos": "WR",
        "bye": None
    },
    "C. McCaffrey": {
        "full": "Christian McCaffrey",
        "team": "SF",
        "pos": "RB",
        "bye": None
    },
    "T. Kelce": {
        "full": "Travis Kelce",
        "team": "KC",
        "pos": "TE",
        "bye": None
    }
}